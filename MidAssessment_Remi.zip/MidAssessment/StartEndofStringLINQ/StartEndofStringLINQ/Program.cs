﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StartEndofStringLINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] str = new string[] { "ROME", "LONDON", "NAIROBI", "CALIFORNIA", "ZURICH", "NEW DELHI", "AMSTERDAM", "ABU DHABI", "PARIS" };
            Console.WriteLine("The cities are:");

            foreach(var n in str)
            {
                Console.Write($"'{n}',");
            }
            Console.WriteLine("");


            var am = str.FirstOrDefault(x => (x.StartsWith("A") && x.EndsWith("M")));

            Console.WriteLine($"The city starting with A and ending with M is : {am}");
        
        }
    }
}
