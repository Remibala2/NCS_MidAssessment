﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayToString_LINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Input number of strings to store in the array : ");
            int count = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"Input {count} strings for the array ");

            string[] str = new string[count];

            for(int i =0; i<count; i++)
            {
                Console.Write($"Element[{i}] : ");
                str[i] = Console.ReadLine();
            }

            Console.WriteLine("Here is the string below created with elements of the above array");

            string arrayToString = String.Join(",", str.Select(x => x.ToString()).ToArray());
            Console.WriteLine(arrayToString);
        }
    }
}
