﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckUserNamePassword
{
    class Program
    {
        static void Main(string[] args)
        {
            string username, password;

                Console.Write("Input a username: ");
                username = Console.ReadLine();

                Console.Write("Input a password: ");
                password = Console.ReadLine();

                if (username != "abcd" || password != "1234")
                Console.WriteLine("The password entered does not match. Please check again!");
            else
                Console.WriteLine("The password entered successfully!");
        }
    }
}
