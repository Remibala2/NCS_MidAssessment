﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrequencyOfCharacters_LINQ
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Input the string: ");
            string str = Console.ReadLine();

            Console.WriteLine("The frequency of characters are : ");

            var s = from x in str
                    group x by x into y
                    select y;
            foreach (var n in s)
            {
                Console.WriteLine("Character  " + n.Key + " : " + n.Count() + " times ");

            }

        }
    }
}
