﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PermutationOfArray
{
    class Program
    {
        public void swapnumber(ref int a, ref int b)
        {
            int temp = a;
            a = b;
            b = temp;
        }
        public void permut(int[] list, int k, int m)
        {
            int i;
            if (k == m)
            {
                for (i = 0; i <= m; i++)
                    Console.Write("{0}", list[i]);
                Console.Write(" ");
            }
            else
                for (i = k; i <= m; i++)
                {
                    swapnumber(ref list[k], ref list[i]);
                    permut(list, k + 1, m);
                    swapnumber(ref list[k], ref list[i]);
                }
        }
        static void Main(string[] args)
        {

            int n, i;
            Program test = new Program();
            int[] array = new int[5];

            Console.Write(" Input the number of elements to store in the array [maximum 5 digits] :");
            n = Convert.ToInt32(Console.ReadLine());
            Console.Write(" Input {0} number of elements in the array :\n", n);
            for (i = 0; i < n; i++)
            {
                Console.Write(" element - {0} : ", i);
                array[i] = Convert.ToInt32(Console.ReadLine());
            }

            Console.Write("\n The Permutations with a combination of {0} digits are : \n", n);
            test.permut(array, 0, n - 1);
            Console.Write("\n\n");

        }
    }
}
