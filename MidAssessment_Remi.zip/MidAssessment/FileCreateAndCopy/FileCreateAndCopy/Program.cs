﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileCreateAndCopy
{
    class Program
    {
        static void Main(string[] args)
        {
            string oldFileName = @"mytest.txt";
            string newFileName = @"mynewtest.txt";

            // Delete the file if it exists.
            if (File.Exists(oldFileName))
            {
                File.Delete(oldFileName);
            }
            using (StreamWriter fileStr = File.CreateText(oldFileName))
            {
                fileStr.WriteLine(" Hello and Welcome /n It is the first content /n of the text file mytest.txt");
            }
            using (StreamReader sr = File.OpenText(oldFileName))
            {
                string s = "";
                Console.WriteLine(" Here is the content of the file {0} : ", oldFileName);
                while ((s = sr.ReadLine()) != null)
                {
                    Console.WriteLine(s);
                }
       
            }

             System.IO.File.Copy(oldFileName, newFileName, true);
            Console.WriteLine(" The file {0} successfully copied to the name {1} in the same directory.", oldFileName, newFileName);

            using (StreamReader sr = File.OpenText(newFileName))
            {
                string str = "";
                Console.WriteLine(" Here is the content of the file {0} : ", newFileName);
                while ((str = sr.ReadLine()) != null)
                {
                    Console.WriteLine(str);
                }

            }

        }
        
    }
}
