﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListOfArrayItems
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mid Assessment");
            Console.WriteLine("Ex2 - Unique elements in an array");
            Console.Write("Input the number of elements in the array : ");

            int count = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine($"Input {count} elements in the array:");

            int[] array = new int[count];
        
   
            for (int i = 0; i < array.Count(); i++)
            {
                Console.Write($"element - {i + 1} : ");
                array[i] = Convert.ToInt32(Console.ReadLine());
            }

            //Distinct
            var uniqueElements = array.Distinct().ToArray();
            Console.WriteLine("Distinct Elements found in the array are - ");
            foreach(int n in uniqueElements)
            {
                Console.WriteLine(n);
            }
            Console.WriteLine("Unique Elements found in the array are");
            //Unique
            for(int i=0; i<count; i++)
            {
                int duplicateCount = 0;
                for (int j=0; j<i;j++)
                {
                    if(array[i]==array[j])
                    {
                        duplicateCount++;
                        
                    }
                }

                for(int k=i+1; k<count; k++)
                {
                    if(array[i] == array[k])
                    {
                        duplicateCount++;
                    }
                }

                if(duplicateCount == 0)
                {
                    Console.WriteLine(array[i]);
                }
               
            }
           
        }
    }
}
