﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoDArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j;
            int[,] array = new int[3, 3];

            Console.WriteLine("Input elements in the matrix :");
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    Console.Write($"element - [{i},{j}] : ");
                    array[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("The matrix is : ");
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    Console.Write($"{array[i,j]}");
                }
                Console.WriteLine("   ");
            }
                  

        }
    
    }
}
