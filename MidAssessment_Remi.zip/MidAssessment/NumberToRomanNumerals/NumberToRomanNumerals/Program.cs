﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberToRomanNumerals
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 2365, 254, 45, 8 };
            string[] roman_value = { "MMM", "MM", "M", "CM", "DCCC", "DCC", "DC", "D", "CD", "CCC", "CC", "C", "XC", "LXXX", "LXX", "LX", "L", "XL", "XXX", "XX", "X", "IX", "VIII", "VII", "VI", "V", "IV", "III", "II", "I" };
            int[] int_value = { 3000, 2000, 1000, 900, 800, 700, 600, 500, 400, 300, 200, 100, 90, 80, 70, 60, 50, 40, 30, 20, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };

           
            foreach (int n in numbers)
            {
                Console.WriteLine($"Original Integer Value : {n}");
                Console.WriteLine($"Roman numerals of the said Integer value :");

                var romanequiv = new StringBuilder();
                var tempn = n;
                var index = 0;
                while (tempn != 0)
                {

                    if (tempn >= int_value[index])
                    {
                        tempn = tempn - int_value[index];
                        romanequiv.Append(roman_value[index]);
                    }
                    else
                    {
                        index++;
                    }
                }
                Console.WriteLine($"{romanequiv}");
            }
        }
    }
}
