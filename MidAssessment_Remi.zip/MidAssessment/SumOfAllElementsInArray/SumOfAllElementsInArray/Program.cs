﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumOfAllElementsInArray
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter number of elements in the array : ");

            int count = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine($"Enter {count} numbers to find Sum:");

            int[] array = new int[count];
            int sum = 0;
            for (int i = 0; i < count; i++)
            {
                Console.Write($"element - {i + 1} : ");
                array[i] = Convert.ToInt32(Console.ReadLine());
                sum = sum + array[i];
            }
            Console.WriteLine($"Sum of all element(s) stored in the array is : {sum}");

        }
    }
}
