﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataFirstApproach_Entity_ADO
{
    class Program
    {
        static void Main(string[] args)
        {
            var context = new ncs2022Entities();

            //View Full Table Data

            var i = context.Libraries.ToList();

            foreach (var j in i )
            {
                Console.WriteLine($"Book Details : \n Book ID - {j.BookID} | Book Name - {j.BookName} | Author Name - {j.AuthorName} | Published Date - {j.PublishingDate} Price - {j.Price}");
            }

            //Add Data

                    var lib = new Library
                    {
                        BookName = "Pride and Prejudice",
                        AuthorName = "Jane Auston",
                        PublishingDate = DateTime.Today,
                        Price = 49.99
                    };

                    context.Libraries.Add(lib);
                    context.SaveChanges();

            //Read Data

            Console.WriteLine($"Enter Book Id to View Details");
            int bookr = Convert.ToInt32(Console.ReadLine());
            Library red = context.Libraries.FirstOrDefault(b => b.BookID == bookr);

            Console.WriteLine($"Book Details : \n Book ID - {red.BookID} | Book Name - {red.BookName} | Author Name - {red.AuthorName} | Published Date - {red.PublishingDate} Price - {red.Price}");

            //Update List
            Library book = context.Libraries.FirstOrDefault(b => b.BookID == 1);
            book.BookName = "The Chicken Soup for the soul";
            book.AuthorName = "Jack Canfield";
            book.Price = 45.60;


            context.SaveChanges();

            //Delete a list item

            Console.WriteLine("Enter Book ID to delete");
            int booki = Convert.ToInt32(Console.ReadLine());
            Library del = context.Libraries.FirstOrDefault(b => b.BookID == booki);

            context.Libraries.Remove(del);

            context.SaveChanges();


        }
    }
}
