﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LanguageEncyclopedia
{
    class Program
    {
        static void Main(string[] args)
        {
            String[] cultureNames = { "en-AU", "sv-SE" };
            String[] str1 = { "case", "encyclopedia"};
            String[] str2 = { "Case", "encyclopedia"};
            StringComparison[] comparisons = (StringComparison[])Enum.GetValues(typeof(StringComparison));

            foreach (var cultureName in cultureNames)
            {
                Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(cultureName);
                Console.WriteLine($"Current Culture: {CultureInfo.CurrentCulture.Name}");
                for (int ctr = 0; ctr <= str1.GetUpperBound(0); ctr++)
                {
                    foreach (var comparison in comparisons)
                        Console.WriteLine("   {0} = {1} ({2}): {3}", str1[ctr],
                                          str2[ctr], comparison,
                                          String.Equals(str1[ctr], str2[ctr], comparison));

                    Console.WriteLine();
                }
                Console.WriteLine();
            }
        }
    }

}