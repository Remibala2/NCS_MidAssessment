﻿namespace LINQToSQL
{
    internal class SampleDbContext
    {
    }
}