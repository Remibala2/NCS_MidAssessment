﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQToSQL
{
    class Program
    {
        static void Main(string[] args)
        {
            LINQToSQLDataContext mydb = new LINQToSQLDataContext();

            var i = mydb.Libraries.ToList();

            foreach (var j in i)
            {
                Console.WriteLine($"Book Details : \n Book ID - {j.BookID} | Book Name - {j.BookName} | Author Name - {j.AuthorName} | Published Date - {j.PublishingDate} Price - {j.Price}");
            }
        }
    }
}
